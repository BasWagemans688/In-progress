const cyclist = document.getElementById('Fietser');
const footer  = document.getElementById('Footer');
let x = -80;
let richting = 1;

function animate() {
  x += 2 * richting; 
  
  if (x > footer.offsetWidth - 50) {
    richting = -1;
    cyclist.style.transform = 'scaleX(-1)';
  }
  if (x <-10){
    richting = 1;
    cyclist.style.transform = 'scaleX(1)';
  }

  cyclist.style.left = x + 'px';
  requestAnimationFrame(animate);
}

requestAnimationFrame(animate);