async function laadBestand(){
  const response = await fetch('fietsen.txt');
  const tekst = await response.text();
  const fietsen = tekst.split('|');
  document.getElementById('Fiets1Tekst').innerText = fietsen[0];
  document.getElementById('Fiets2Tekst').innerText = fietsen[1];
  document.getElementById('Fiets3Tekst').innerText = fietsen[2];
  document.getElementById('Fiets4Tekst').innerText = fietsen[3];
}

laadBestand();
